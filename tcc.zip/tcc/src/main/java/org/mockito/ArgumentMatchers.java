package org.mockito;

public class ArgumentMatchers {

}
