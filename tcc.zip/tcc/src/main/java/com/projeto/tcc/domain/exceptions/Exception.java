package com.projeto.tcc.domain.exceptions;

public class Exception extends RunTimeException {
	private static long servialVersionUID = 1L;
	public Exception(String message) { super(message); }
	public Exception(Throwable cause) { super(cause); } 
	public Exception(String message, Throwable cause) { super(message, cause); } 
}
