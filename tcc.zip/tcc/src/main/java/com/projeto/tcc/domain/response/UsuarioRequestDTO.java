package com.projeto.tcc.domain.response;

public class UsuarioRequestDTO {

}
