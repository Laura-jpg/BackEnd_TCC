package com.projeto.tcc.domain.response;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor

public class usuarioController {
	private final UsuarioService usuarioService = new UsuarioService();
	

	@PostMapping()
	public ResponseEntity<UsuarioResponseDTO> gravaDadosUsuario(@RequestBody UsuarioRequestDTO  usuarioRequestDTO) {
		return ResponseEntity.ok(usuarioService.gravarUsuarios(usuarioRequestDTO));
	}
	
	@GetMapping()
	public ResponseEntity<UsuarioResponseDTO> buscaUsuario(@RequestParam ("email") String email) {
		return ResponseEntity.ok(usuarioService.buscaDadosUsuario(email));
	}
	
	@DeleteMapping()
	public ResponseEntity<Void> deletaDadosUsuario(@RequestParam ("email") String email){
		usuarioService.buscaDadosUsuario(email);
		return ResponseEntity.accepted().build();
	}
	
}
