package com.projeto.tcc.domain.exceptions;

public class RunTimeException {

}
