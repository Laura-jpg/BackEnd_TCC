package com.projeto.tcc.domain.entity.converter;
import java.util.UUID;
import org.springframework.stereotype.Component;
import com.projeto.tcc.domain.entity.UsuarioEntity;
import com.projeto.tcc.domain.response.UsuarioRequestDTO;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class UsuarioConverter {

	public UsuarioEntity paraUsuarioEntity(UsuarioRequestDTO usuarioDTO) {
		return UsuarioEntity.builder()
				.id(UUID.randomUUID().toString())
				.nome(usuarioDTO.getNome())
				.sobrenome(usuarioDTO.getSobrenome())
				.email(usuarioDTO.getEmail())
				.senha(usuarioDTO.getSenha())
				.build();
	}
}
