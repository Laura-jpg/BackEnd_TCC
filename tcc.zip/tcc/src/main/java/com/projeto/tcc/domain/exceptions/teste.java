package com.projeto.tcc.domain.exceptions;

public class teste {

	public static void main(String[] args ) {
		System.out.println("Ola!");
	}
	
}
