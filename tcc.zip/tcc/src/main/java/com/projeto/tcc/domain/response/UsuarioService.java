package com.projeto.tcc.domain.response;
import static org.mockito.ArgumentMatchers.notNull;
import org.springframework.stereotype.Service;
import com.projeto.tcc.domain.entity.UsuarioEntity;
import com.projeto.tcc.domain.entity.converter.UsuarioConverter;
import com.projeto.tcc.domain.entity.converter.UsuarioMapper;
import com.projeto.tcc.domain.repository.UsuarioRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor

public class UsuarioService {
	private final UsuarioRepository usuarioRepository;
	private final UsuarioConverter usuarioConverter;
	private final UsuarioMapper usuarioMapper = null;

	public UsuarioEntity salvaUsuario(UsuarioEntity usuarioEntity) {
		return usuarioRepository.save(usuarioEntity);
	}
	
	public UsuarioResponseDTO gravarUsuarios(UsuarioRequestDTO usuarioRequestDTO) {
		try {
			notNull(usuarioRequestDTO, "Os dados do usuário são obrigatórios");
			UsuarioEntity usuarioEntity = salvaUsuario(usuarioConverter.paraUsuarioEntity(usuarioRequestDTO));
			return usuarioMapper.paraUSuarioResponseDTO(usuarioEntity);
		} catch (Exception e) {
			throw new Exception ("Erro ao gravar dados", e);
		}
	}
	public UsuarioResponseDTO buscaDadosUsuario(String email) {
		try {
			UsuarioEntity entity = usuarioRepository.findByEmail(email);
			notNull(entity, "Usuário não encontrado");
			
			return usuarioMapper.paraUSuarioResponseDTO(entity);
		} catch (Exception e) {
			throw new Exception ("Erro ao buscar dados", e);
		}
		
	}
	
	@Transactional
	public void deletaUsuario(String email) {
		UsuarioEntity entity = usuarioRepository.findByEmail(email);
		usuarioRepository.deleteByEmail(email);
	}
}
