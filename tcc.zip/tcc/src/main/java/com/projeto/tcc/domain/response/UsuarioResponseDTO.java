package com.projeto.tcc.domain.response;

public record UsuarioResponseDTO (Long id, 
		String nome, 
		String sobrenome,
		String email,
		String senha) {
}
