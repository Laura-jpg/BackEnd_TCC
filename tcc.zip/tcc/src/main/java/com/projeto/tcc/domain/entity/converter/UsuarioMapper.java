package com.projeto.tcc.domain.entity.converter;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import com.projeto.tcc.domain.entity.UsuarioEntity;
import com.projeto.tcc.domain.response.UsuarioResponseDTO;
@Mapper(componentModel = "spring")

public interface UsuarioMapper {
	
	@Mapping(target = "id", source = "usuario.id")
	@Mapping(target = "nome", source = "usuario.nome")
	@Mapping(target = "sobrenome", source = "usuario.sobrenome")
	@Mapping(target = "email", source = "usuario.email")
	@Mapping(target = "senha", source = "usuario.senha")
	
	UsuarioResponseDTO paraUSuarioResponseDTO(UsuarioEntity usuario);
}
