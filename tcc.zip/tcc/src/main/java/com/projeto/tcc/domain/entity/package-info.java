/**
 * 
 */
/**
 * @author LAURA ELLEN
 *
 */
package com.projeto.tcc.domain.entity;