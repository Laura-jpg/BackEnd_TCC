package com.projeto.tcc.domain.repository;
import org.springframework.data.mongodb.repository.MongoRepository;
import com.projeto.tcc.domain.entity.UsuarioEntity;
import jakarta.transaction.Transactional;


public interface UsuarioRepository extends MongoRepository <UsuarioEntity, String>{
	UsuarioEntity findByEmail(String email);
	
	@Transactional
	void deleteByEmail(String email);
	
}
