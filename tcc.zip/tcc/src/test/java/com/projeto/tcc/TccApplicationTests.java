package com.projeto.tcc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TccApplicationTests {

	@Test
	void contextLoads() {
	}

}
